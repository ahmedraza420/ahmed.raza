const collections = {
  users: 'users'
};

export = collections
